    <nav class="navbar navbar-dark bg-dark">			
      	<div class="container-fluid">
      		<div class="row align-items-center">
      			<div class="col-9">
				<h3 class="text-white text-center">SAOG - Sistema de Apoio Operacional e Gestão - GEOPE SE/BSB</h3>
				</div>
				<div class="col-2">
			  	<h5 class="text-white text-center" id="nome_usuario"></h5>
			  	</div>
			  	<div class="col-1">
			  	<button class="btn btn-outline-warning btn-sm border border-warning" id="logout" onclick="logout();">Sair</button>
			  	</div>
			  </div>
		</div>
	</nav>